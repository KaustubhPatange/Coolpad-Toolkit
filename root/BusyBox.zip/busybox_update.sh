#!/sbin/sh
#

BB="busybox"
FIND="$BB find"
XARGS="$BB xargs"
LS="$BB ls"
GREP="$BB grep"
AWK="$BB awk"
RM="$BB rm"

cd /system/xbin
$FIND . -type l | $XARGS -r $LS -l | $GREP busybox | $AWK '{print $9}' | $XARGS -r $RM -f
